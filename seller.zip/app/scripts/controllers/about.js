'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
