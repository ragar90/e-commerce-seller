'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:AddProductCtrl
 * @description
 * # AddProductCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('AddProductCtrl', ['$scope','$http','url','sellers','$window','fileUpload','$compile','$location', function($scope,$http,url,sellers,$window,fileUpload,$compile,$location) {
    var category_url = url+'api/v1/categories/get-approved-categories';
      $scope.si="";
     $http.get(category_url).success(function(data){
        if(data['status']=='success'){
          $scope.category = data['response']['categories'];

        }


     });
      $scope.images =[];
      $scope.image_counter=0;

     $scope.choices = [{id: '1'}, {id: '2'}];
     $scope.addNewChoice = function() {
        var newItemNo = $scope.choices.length+1;
        $scope.choices.push({'id':+newItemNo});
      };

    $scope.removeChoice = function() {
      var lastItem = $scope.choices.length-1;
      $scope.choices.splice(lastItem);
    };

     $scope.sub_category = function () {

       if($scope.c ==0){
         return;
       }
       var category_url = url+'api/v1/categories/get-approved-categories?parent_id='+$scope.c;
        $http.get(category_url).success(function(data){
            $scope.subcategory = data['response']['categories'];
            $scope.donglee = "";

         });

     }
     $scope.remove_image =function(id){
       //alert(id);
       $("#"+id).remove();
     }

     $scope.submiting = function () {


       var variant_quantity =$("#choicesDisplay").html();
       variant_quantity = JSON.parse(variant_quantity);

       var new_url  = url+'api/v1/products/add-product';
       var authorization = $window.localStorage['Authorization'];

      var req = {
          method: 'POST',
          url: new_url,
          headers: {
              'Authorization':authorization
          },
          data: {"images":$scope.images,"variants":variant_quantity,"quantity":$scope.quantity,"title":$scope.name,"name":$scope.name,"category":$scope.c,"subcategory":$scope.donglee,'description':$scope.description,"sku":$scope.sku,"price":$scope.main_price,"selling_price":$scope.selling_price,"commission":$scope.commision,"service_tax":$scope.service_tax,"weight":$scope.weight,"shipping_fee":$scope.shipping_fee,"ship_duration":$scope.ship_duration,"paid_by":$scope.paid_by}
        }
        $http(req).then(function(data){
            if(data.data.status =="success"){
              $location.path("yet_to_be_approved");
            }else{
              alert("Sever Error Please Add Again");
            }
        });

     }


     $scope.uploadFiles = function(selection){

       var file = $scope[selection];
       console.log('file is ' );
       $scope.image_counter = $scope.image_counter+1;

       var uploadUrl = url+"api/v1/images/upload-single-image";

       fileUpload.uploadFileToUrl(file, uploadUrl,selection,function(id){
       $scope.images.push(id);},$scope.image_counter,function(ib,remove_image_id){
         remove_image_id ="'"+remove_image_id+"'";

         var open_div ='<div class="col-md-6" id='+remove_image_id+' style="padding:0px;">';
         var close_div='</div>';
         var image_url =open_div+'<input type="button" style="margin:5px;padding:0px 6px;font-weight:900" class="btn btn-danger" btn-sm value="-" ng-click="remove_image('+remove_image_id+')"/><img style="width:400px" class="img-responsive" src ="'+ib+'"/>'+close_div;
         image_url =$compile(image_url)($scope);
         $("#image_url1").append(image_url);

       });
   };



    $scope.calculate_price = function () {
      var main_price = $scope.main_price;
      var selling_price =$scope.selling_price;
      $scope.error="";
      if(selling_price){
        if(selling_price > main_price){
          $scope.error="Price after Discount should be less than Item Price";
          console.log("fd");
          return;
        }
        var actual_commision =($scope.selling_price*5)/100;
        $scope.commision=actual_commision;
        var service_tax =(actual_commision*15)/100;
        $scope.service_tax=service_tax;
        var total_earn = selling_price - (actual_commision+service_tax);
        total_earn = $scope.main_price-total_earn;
        $scope.total_earn =total_earn;



      }else{
        var actual_commision =($scope.main_price*5)/100;
        $scope.commision=actual_commision;
        var service_tax =(actual_commision*15)/100;
        $scope.service_tax=service_tax;
        var total_earn = actual_commision+service_tax;
        total_earn = $scope.main_price-total_earn;
        $scope.total_earn =total_earn;
      }
    }


  }]).directive('fileModel', ['$parse', function ($parse) {
              return {
                 restrict: 'A',
                 link: function(scope, element, attrs) {
                    var model = $parse(attrs.fileModel);
                    var modelSetter = model.assign;

                    element.bind('change', function(){
                       scope.$apply(function(){
                          modelSetter(scope, element[0].files[0]);
                       });
                    });
                 }
              };
}]).service('fileUpload', ['$http','$compile', function ($http,$compile) {

            this.uploadFileToUrl = function(file, uploadUrl,selection,cb,image_counter,ib){
               var fd = new FormData();
               fd.append('image', file);

               $http.post(uploadUrl, fd, {
                  transformRequest: angular.identity,
                  headers: {'Content-Type': undefined}
               })

               .success(function(data){
                if(data['status'] == 'success'){
                  var image_id = data.response._id;

                  var url_new = data.response.url;

                  cb(image_id);
                  ib(url_new,image_id);
                }
               })

               .error(function(data){
                 console.log(data);
               });
            }
 }]);
