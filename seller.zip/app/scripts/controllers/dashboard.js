'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:DashboardCtrl
 * @description
 * # DashboardCtrl
 * Controller of the ecommercesellerApp
 */

angular.module('ecommercesellerApp')
  .controller('HeadersCtrl', ['$scope','$window','$location', function($scope, $window,$location) {
    var authorization = $window.localStorage['Authorization'];

    if(!authorization){
        $location.path('signin');
    }
    $scope.global_name =$window.localStorage['global_name'];
    $scope.global_logo=$window.localStorage['global_logo'];
    $scope.logout =function(){

      localStorage.removeItem('global_name');
      localStorage.removeItem('Authorization');
      $location.path('signin');

    }


  }]).controller('DashboardCtrl', ['$scope','$http','$location','$window','url','sellers','imageUpload','saveImage', function($scope,$http,$location,$window,url,sellers,imageUpload,saveImage) {

    //Fetch the basic information
    var authorization = $window.localStorage['Authorization'];

    if(!authorization){
        $location.path('signin');
    }
    var main_url =url+sellers+"get-profile";
    var req = {
       method: 'GET',
       url:main_url,
       headers: {
           'Authorization':authorization
       },
     }
     $http(req).then(function(data){
       console.log(data);
       if(data.data.status =='success'){
         $scope.sellers = data.data.response;
         $scope.address = data.data.response.address[0].address;
         $scope.phone =data.data.response.address[0].phone;
         $scope.city =data.data.response.address[0].city;
         $scope.pincode =data.data.response.address[0].pincode;
         $scope.state=data.data.response.address[0].state;
         $scope.country=data.data.response.address[0].country;
         if(data.data.response.logo){
            $scope.logo =data.data.response.logo.url;
         }else{
             $scope.logo ="";
         }
         if(data.data.response.banner){
           $scope.banner=data.data.response.banner.url;
         }else{
           $scope.banner="";
         }

         $window.localStorage['global_name']=$scope.sellers.name;
         $window.localStorage['global_logo']=$scope.logo;


       }

     });

//Saving shoppers details
    $scope.shop_details = function (){
      var new_url  = url+sellers+'update-profile';
      var authorization = $window.localStorage['Authorization'];

     var req = {
         method: 'POST',
         url: new_url,
         headers: {
             'Authorization':authorization
         },
         data: {"name":$scope.sellers.name,"email":$scope.email,"address":$scope.address,"password":$scope.password,"phone":$scope.phone,"city":$scope.city,"state":$scope.state,"country":$scope.country,"pincode":$scope.pincode,"govt_issue_card":$scope.sellers.govt_issue_card,"business_registration":$scope.sellers.business_registration}
       }
       $http(req).then(function(data){
           if(data.data.status =="success"){
             alert("Updated Successfully");

           }else{
             alert("no");
           }
       });
    }

    $scope.uploadFile = function(selection){

      var file = $scope[selection];
      console.log('file is ' );
      //console.dir(file);


      var uploadUrl = url+"api/v1/images/upload-single-image";
      imageUpload.uploadFileToUrl(file, uploadUrl,selection);
  };







  }]).directive("w3TestDirective", function() {
      return {
          templateUrl : "views/templates/header.html",
          controller:"HeadersCtrl"
      };
  }).directive("sidebar", function() {
      return {
          templateUrl : "views/templates/sidebar.html",
          controller:"HeadersCtrl"
      };
  }).directive('fileModel', ['$parse', function ($parse) {
              return {
                 restrict: 'A',
                 link: function(scope, element, attrs) {
                    var model = $parse(attrs.fileModel);
                    var modelSetter = model.assign;

                    element.bind('change', function(){
                       scope.$apply(function(){
                          modelSetter(scope, element[0].files[0]);
                       });
                    });
                 }
              };
}]).service('imageUpload', ['$http','saveImage', function ($http,saveImage) {
            this.uploadFileToUrl = function(file, uploadUrl,selection){
               var fd = new FormData();
               fd.append('image', file);


               $http.post(uploadUrl, fd, {
                  transformRequest: angular.identity,
                  headers: {'Content-Type': undefined}
               })

               .success(function(data){
                if(data['status'] == 'success'){
                  var image_id = data.response._id;
                  saveImage(image_id,selection);

                }
               })

               .error(function(data){
                 console.log(data);
               });
            }
 }]).service('saveImage', ['$http','$window','url','sellers','$location', function ($http,$window,url,sellers,$location) {

   return function(id,selection) {


     if(selection =='logo'){
          var logo_banner ={'logo':id};
     }
     if(selection =='banner'){

         var logo_banner ={'banner':id};
     }

    var new_url  = url+sellers+'update-profile';
    var authorization = $window.localStorage['Authorization'];

    var req = {
        method: 'POST',
        url: new_url,
        headers: {
            'Authorization':authorization
        },
        data: logo_banner,
      }
      $http(req).then(function(data){
          if(data.data.status =="success"){
            alert("c");
            $window.location.reload();

          }else{
            alert("Upload failed");
          }
      });

   }

  }]);
