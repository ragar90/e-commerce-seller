'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:TrackOrderCtrl
 * @description
 * # TrackOrderCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('TrackOrderCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
