'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:OrderPickUpCtrl
 * @description
 * # OrderPickUpCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('OrderPickUpCtrl', ['$scope','$http','url','sellers','$window','order', function($scope,$http,url,sellers,$window,order) {
    var authorization = $window.localStorage['Authorization'];

    if(!authorization){
        $location.path('signin');
    }
      new order({status:"Pick Up Scheduled"}).$get(function(data){
          console.log(data);
        //  $scope.orders =data.data.Resource;
        if(data["status"]=="success"){
          $scope.orders = data["response"]["orders"];

        }
      },function(data){

      });

  }]);
