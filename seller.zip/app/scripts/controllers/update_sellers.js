'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:UpdateSellersCtrl
 * @description
 * # UpdateSellersCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('UpdateSellersCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
