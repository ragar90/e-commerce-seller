'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:ForgotPasswordCtrl
 * @description
 * # ForgotPasswordCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('ForgotPasswordCtrl',['$scope','$http','$location','$window','url','sellers', function($scope,$http,$location,$window,url,sellers) {

    $scope.master = {};

    $scope.update = function(user) {
      $scope.master = angular.copy(user);
    };

    $scope.reset = function() {
      $scope.user = angular.copy($scope.master);
    };
    $scope.submit = function () {
      //$window.localStorage['Authorization']="nikitajain14";

      //alert($window.localStorage['Authorization']);

        var main_url = url+sellers+"forgot";
      $http.post(main_url,{"email":$scope.email}).success(function(data){
        if (data['status'] == 'success') {
         $window.localStorage['Authorization']=data['response']['token'];
          //$location.path('/dashboard');
        }else{
         alert('Forgot Password failed');
        }
      });

    }

    $scope.reset();
  }]);
