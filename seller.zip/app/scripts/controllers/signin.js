'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:SigninCtrl
 * @description
 * # SigninCtrl
 * Controller of the ecommercesellerApp
 */





angular.module('ecommercesellerApp')
  .controller('SigninCtrl', ['$scope','$http','$location','$window','url','sellers', function($scope,$http,$location,$window,url,sellers) {

    $scope.master = {};

    $scope.update = function(user) {
      $scope.master = angular.copy(user);
    };

    $scope.reset = function() {
      $scope.user = angular.copy($scope.master);
    };
    $scope.submit = function () {
      //$window.localStorage['Authorization']="nikitajain14";

      //alert($window.localStorage['Authorization']);

        var main_url = url+sellers+"login";
      $http.post(main_url,{"email":$scope.email,"password":$scope.password}).success(function(data){
        if (data['status'] == 'success') {
         $window.localStorage['Authorization']=data['response']['token'];
          $location.path('/dashboard');
        }else{
          if(data["statusCode"]==500){
              if(data["statusMessage"]=="Invalid Password"){
                alert("Please enter the correct Password");
              }
              if(data["statusMessage"]=='Invalid Mail'){
                alert("Please enter the Correct Email Id");
              }
          }else{
              alert("Server Error");
          }
        }
      });

    }

    $scope.reset();
  }]);
