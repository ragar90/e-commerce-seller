'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:EditProductCtrl
 * @description
 * # EditProductCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('EditProductCtrl',['$scope','$http','url','sellers','$window','$routeParams', function($scope,$http,url,sellers,$window,$routeParams) {
    var authorization = $window.localStorage['Authorization'];

    if(!authorization){
        $location.path('signin');
    }
    $scope.new_array={};
    $scope.choices = [{_id: '1'}];
    $scope.addNewChoice = function() {
       var newItemNo = $scope.choices.length+1;
       $scope.choices.push({'id':+newItemNo});
     };

   $scope.removeChoice = function() {
     var lastItem = $scope.choices.length-1;
     $scope.choices.splice(lastItem);
   };

    var category_url = url+'api/v1/categories/get-approved-categories';
    $scope.si="";
    $scope.donglee ="";
    var new_url  = url+'api/v1/products/get-single-product/'+$routeParams.id;
    var authorization = $window.localStorage['Authorization'];
    var req = {
       method: 'Get',
       url: new_url,
       headers: {
           'Authorization': authorization
       }
     }
     $http(req).then(function(data){
         if(data.data.status =="success"){

            $scope.product_details = data.data.response.product;
            $scope.title =data.data.response.product.title;
            $scope.main_price = data.data.response.product.pricing.original;
            $scope.selling_price=data.data.response.product.pricing.after_discount;
            $scope.commision=data.data.response.product.pricing.commission;
            $scope.service_tax= data.data.response.product.pricing.service_tax;
            $scope.shipping_fee =data.data.response.product.shipping_details.fee;
            $scope.product_id=data.data.response.product._id;
            $scope.sku=data.data.response.product.sku;
            $scope.quantity=data.data.response.product.quantity;
            $scope.description=data.data.response.product.description;
            $scope.variants =data.data.response.product.variants;
            $scope.images = data.data.response.product.images;



            $http.get(category_url).success(function(data){
               if(data['status']=='success'){
                 $scope.category = data['response']['categories'];
                 $scope.category.forEach(function(item) {
                   if($scope.product_details.categories.indexOf(item._id) !==-1) {
                     $scope.c = item._id;
                     $scope.sub_category();
                   }
                 })
               }
            });
            if(data.data.response.product.paid_by_buyer == false){

              $scope.me = true;
              $scope.buyer =false;
            }else{

              $scope.me = false;
              $scope.buyer =true;

            }

         }  else{
           alert("no");
         }
     });
     $scope.submiting = function () {


       var product_id = $scope.product_id;
       //console.log($scope.variants);

      // console.log($scope.choices);
       $scope.variants.forEach(function(item) {
         $scope.choices.push(item);
       })

      // product_id ="57a859359fad44c5531dba31";
       var new_url  = url+'api/v1/products/update-product/'+product_id;
       var authorization = $window.localStorage['Authorization'];


      var req = {
          method: 'PUT',
          url: new_url,
          headers: {
              'Authorization':authorization
          },
          data: {"variants":$scope.choices,"quantity":$scope.quantity,"title":$scope.title,"name":$scope.title,"category":$scope.c,"subcategory":$scope.donglee,'description':$scope.description,"sku":$scope.sku,"price":$scope.main_price,"selling_price":$scope.selling_price,"commission":$scope.commision,"service_tax":$scope.service_tax,"weight":$scope.weight,"shipping_fee":$scope.shipping_fee,"ship_duration":$scope.ship_duration,"paid_by":0}
        }
        $http(req).then(function(data){
            if(data.data.status =="success"){
              alert("Yes");
            }else{
              alert("no");
            }
        });

     }

     $scope.calculate_price = function () {
       var main_price = $scope.main_price;
       var selling_price =$scope.selling_price;
       $scope.error="";
       if(selling_price){
         if(selling_price > main_price){
           $scope.error="Price after Discount should be less than Item Price";
           console.log("fd");
           return;
         }
         var actual_commision =($scope.selling_price*5)/100;
         $scope.commision=actual_commision;
         var service_tax =(actual_commision*15)/100;
         $scope.service_tax=service_tax;
         var total_earn = selling_price - (actual_commision+service_tax);
         total_earn = $scope.main_price-total_earn;
         $scope.total_earn =total_earn;


       }else{
         var actual_commision =($scope.main_price*5)/100;
         $scope.commision=actual_commision;
         var service_tax =(actual_commision*15)/100;
         $scope.service_tax=service_tax;
         var total_earn = actual_commision+service_tax;
         total_earn = $scope.main_price-total_earn;
         $scope.total_earn =total_earn;
       }
     }
     $scope.sub_category = function () {

       if($scope.c ==0){
         return;
       }
       var category_url = url+'api/v1/categories/get-approved-categories?parent_id='+$scope.c;
        $http.get(category_url).success(function(data){
            $scope.subcategories = data['response']['categories'];
         });

     }
  }]);
