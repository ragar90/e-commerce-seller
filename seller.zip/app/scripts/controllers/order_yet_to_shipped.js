'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:OrderYetToShippedCtrl
 * @description
 * # OrderYetToShippedCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('OrderYetToShippedCtrl', ['$scope','$http','url','sellers','$window','order', function($scope,$http,url,sellers,$window,order) {
    var authorization = $window.localStorage['Authorization'];

    if(!authorization){
        $location.path('signin');
    }
      new order({status:"Yet To Be Shipped"}).$get(function(data){
          console.log(data);
        //  $scope.orders =data.data.Resource;
        if(data["status"]=="success"){
          $scope.orders = data["response"]["orders"];

        }
      },function(data){

      });
      $scope.track_status = function (id,product,status,tracking){

        if(tracking){
          tracking = tracking;
        }else{
          tracking=0;
        }

        var new_url = url+sellers+"tracking/update/"+id+"/"+product+"?status="+status;
        var authorization = $window.localStorage['Authorization'];
        var req = {
           method: 'PUT',
           url: new_url,
           headers: {
               'Authorization':authorization
           },
           data:{"tracking_number":tracking}

         }
         $http(req).then(function(data){
           console.log(data);
             if(data.data.status =="success"){
               $("#"+id).remove();

             }else{
               alert("Server error");
             }
         });


      }
  }]);
