'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:OrderPendingCtrl
 * @description
 * # OrderPendingCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('OrderPendingCtrl', ['$scope','$http','url','sellers','$window','order', function($scope,$http,url,sellers,$window,order) {
    var authorization = $window.localStorage['Authorization'];

    if(!authorization){
        $location.path('signin');
    }
      new order({status:"Not Approved"}).$get(function(data){
          console.log(data);
        //  $scope.orders =data.data.Resource;
        if(data["status"]=="success"){
          $scope.orders = data["response"]["orders"];

        }
      },function(data){

      });
      // {{url}}/api/v1/sellers/orders/update/order_id/product_id?status=
      $scope.change_status = function (id,product,status){
        var new_url = url+sellers+"orders/update/"+id+"/"+product+"?status="+status;
        var authorization = $window.localStorage['Authorization'];
        var req = {
           method: 'PUT',
           url: new_url,
           headers: {
               'Authorization':authorization
           },

         }
         $http(req).then(function(data){
           console.log(data);
             if(data.data.status =="success"){
               $("#"+id).remove();

             }else{
               alert("Server error");
             }
         });


      }
  }]);
