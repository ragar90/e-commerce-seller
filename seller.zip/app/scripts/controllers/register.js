'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:RegisterCtrl
 * @description
 * # RegisterCtrl
 * Controller of the ecommercesellerApp
 */


angular.module('ecommercesellerApp')
  .controller('RegisterCtrl', ['$scope','$http','url','sellers','$location', function($scope,$http,url,sellers,$location) {
    console.log(url);
    $scope.master = {};

    $scope.update = function(user) {
      $scope.master = angular.copy(user);
    };

    $scope.reset = function() {
      $scope.user = angular.copy($scope.master);
    };
    $scope.submit = function () {
      var main_url = url+sellers+"/register";

       $http.post(main_url,{"name":$scope.name,"email":$scope.email,"address":$scope.address,"password":$scope.password,"phone":$scope.phone,"city":$scope.city,"state":$scope.state,"country":$scope.country,"pincode":$scope.pincode,"govt_issue_card":$scope.govt_issue_card,"business_registration":$scope.business_registration}).success(function(data){

         if(data['status'] == 'success'){
           console.log("test");
           $location.path('signin');
         }else{
            if(data['statusCode']== 500){
              alert("Email-id already exist.Please try with other Email-id");
            }else{
              alert("Server Error");
            }
         }
       });

    }

    $scope.reset();
  }] );
