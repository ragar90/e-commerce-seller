'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:HeaderCtrl
 * @description
 * # HeaderCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('HeaderCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
