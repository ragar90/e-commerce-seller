'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
