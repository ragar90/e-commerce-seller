'use strict';

/**
 * @ngdoc function
 * @name ecommercesellerApp.controller:SidebarCtrl
 * @description
 * # SidebarCtrl
 * Controller of the ecommercesellerApp
 */
angular.module('ecommercesellerApp')
  .controller('SidebarCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
